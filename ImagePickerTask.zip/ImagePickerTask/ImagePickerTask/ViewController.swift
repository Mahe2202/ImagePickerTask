//
//  ViewController.swift
//  ImagePickerTask
//
//  Created by Hemanth on 24/04/19.
//  Copyright © 2019 Apple pc. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UIImagePickerControllerDelegate, UICollectionViewDelegateFlowLayout, UINavigationControllerDelegate{

    var imgArr = [UIImage]()
    var imgPicker = UIImagePickerController()
    
    @IBOutlet var collVwDelegate: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgPicker.delegate = self
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  imgArr.count + 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colectionViewCell", for: indexPath) as! CollectionViewCell
        
        cell.imgCell.layer.cornerRadius = 10
        cell.imgCell.clipsToBounds = true
        
        cell.btnAddImg.addTarget(self, action: #selector(ImgPickerAction( _:)), for: .touchUpInside)
        
        
        
        cell.imgCell.isHidden = true
        

        
        if indexPath.row == imgArr.count
        {
            cell.btnAddImg.isHidden = false
       
            
        } else {
            cell.btnAddImg.isHidden = true
            cell.imgCell.isHidden = false
            cell.imgCell.image = imgArr[indexPath.row]
          
        }
        
        return cell
    }
    
    @objc private func ImgPickerAction(_ sender: UIButton!) {
        
        showimagepicker()
    }
    
    func showimagepicker()
        
    {
        imgPicker.sourceType = .photoLibrary
        imgPicker.allowsEditing = true
        present(imgPicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let pickedImage = info[.editedImage] {
            imgArr.append(pickedImage as! UIImage)
            collVwDelegate.reloadData()
        }
        dismiss(animated: true, completion: nil)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if imgArr.count == indexPath.row
        {
            if ((indexPath.row + 1) % 2 == 0) {
                return CGSize.init(width: self.collVwDelegate.frame.width / 2, height: self.collVwDelegate.frame.height / 4)
            }else{
                return CGSize.init(width: self.collVwDelegate.frame.width, height: self.collVwDelegate.frame.height / 4)
                
            }
        }else{
            return CGSize.init(width: self.collVwDelegate.frame.width / 2, height: self.collVwDelegate.frame.height / 4)
            
        }

    }
}

