//
//  CollectionVwImgsVC.swift
//  ImagePickerTask
//
//  Created by MAHi on 24/04/19.
//  Copyright © 2019 Apple pc. All rights reserved.
//

import UIKit

class CollectionVwImgsVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout , MyDataSendingDelegateProtocol {
    
    var imgArr = [UIImage]()
    var imagePicker = pickerViewController()
    
     @IBOutlet var collVwDelegate: UICollectionView!
     override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  imgArr.count + 1
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colectionViewCell", for: indexPath) as! CollectionViewCell
        
        cell.imgCell.layer.cornerRadius = 10
        cell.imgCell.clipsToBounds = true
        
        cell.btnAddImg.addTarget(self, action: #selector(ImgPickerAction( _:)), for: .touchUpInside)
        cell.imgCell.isHidden = true
        
        if indexPath.row == imgArr.count
        {
            cell.btnAddImg.isHidden = false
            
            
        } else {
            cell.btnAddImg.isHidden = true
            cell.imgCell.isHidden = false
            cell.imgCell.image = imgArr[indexPath.row]
            
        }
        
        return cell
    }
    // Delegate methode...Data Passing
    func sendData(myData: [UIImage])
    {
        imgArr = myData
        collVwDelegate.reloadData()
    }
    // PickedImage Action...
     @objc private func ImgPickerAction(_ sender: UIButton!) {
        
        imagePicker.delegateImage = self
        imagePicker.alertfun(Vc: self)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if imgArr.count == indexPath.row
        {
            if ((indexPath.row + 1) % 2 == 0) {
                return CGSize.init(width: self.collVwDelegate.frame.width / 2, height: self.collVwDelegate.frame.height / 4)
            }else{
                return CGSize.init(width: self.collVwDelegate.frame.width, height: self.collVwDelegate.frame.height / 4)
                
            }
        }else{
            return CGSize.init(width: self.collVwDelegate.frame.width / 2, height: self.collVwDelegate.frame.height / 4)
            
        }
        
    }

}
