//
//  CollectionViewCell.swift
//  ImagePickerTask
//
//  Created by MAHi on 24/04/19.
//  Copyright © 2019 Apple pc. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var btnAddImg: UIButton!
    @IBOutlet var imgCell: UIImageView!
    
    
}
