//
//  pickerViewController.swift
//  ImgPickerClass
//
//  Created by MAHi on 24/04/19.
//  Copyright © 2019 Apple pc. All rights reserved.
//

import UIKit


protocol MyDataSendingDelegateProtocol {
    func sendData(myData: [UIImage])
}

class pickerViewController: UIImagePickerController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    var delegateImage : MyDataSendingDelegateProtocol?
    var imageValue = [UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    // Show imagePicker func......
    func alertfun(Vc: UIViewController)
    {
        if imageValue.count < 100
        {
        self.sourceType = .photoLibrary
        self.delegate = self
        self.allowsEditing = true
        Vc.present(self, animated: true, completion: nil)
        }
        else{
            print("Somehting Worrong")
        }
      
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
         if let image = info[UIImagePickerControllerEditedImage]
        {
            imageValue.append(image as! UIImage)

            self.delegateImage?.sendData(myData: imageValue)
          
        }
        else
        {
            print("Something Worrong")
        }
        dismiss(animated: true, completion: nil)
        
    }

}
